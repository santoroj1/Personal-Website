To compile, use 

	g++ -std=c++0x *.cpp *.h 

and then use 

	./a.out 

to run.  Be sure that the input file is in the same directory as the run file and is entitled "sample-input.txt"
﻿namespace JohnSantoroFinalProject
{
    partial class Calculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Button7Digit = new System.Windows.Forms.Button();
            this.Button8Digit = new System.Windows.Forms.Button();
            this.Button9Digit = new System.Windows.Forms.Button();
            this.DivisionButton = new System.Windows.Forms.Button();
            this.SqrtButton = new System.Windows.Forms.Button();
            this.Button4Digit = new System.Windows.Forms.Button();
            this.Button5Digit = new System.Windows.Forms.Button();
            this.Button6Digit = new System.Windows.Forms.Button();
            this.MultiplyButton = new System.Windows.Forms.Button();
            this.PercentButton = new System.Windows.Forms.Button();
            this.Button1Digit = new System.Windows.Forms.Button();
            this.Button2Digit = new System.Windows.Forms.Button();
            this.Button3Digit = new System.Windows.Forms.Button();
            this.SubtractionButton = new System.Windows.Forms.Button();
            this.InverseButton = new System.Windows.Forms.Button();
            this.Button0Digit = new System.Windows.Forms.Button();
            this.SignButton = new System.Windows.Forms.Button();
            this.DecimalButton = new System.Windows.Forms.Button();
            this.AdditionButton = new System.Windows.Forms.Button();
            this.SolveButton = new System.Windows.Forms.Button();
            this.AddToMemoryButton = new System.Windows.Forms.Button();
            this.MemoryStoreButton = new System.Windows.Forms.Button();
            this.MemoryRecallButton = new System.Windows.Forms.Button();
            this.ClearMemoryButton = new System.Windows.Forms.Button();
            this.BackspaceButton = new System.Windows.Forms.Button();
            this.ClearEntryButton = new System.Windows.Forms.Button();
            this.ClearButton = new System.Windows.Forms.Button();
            this.MemoryExistsBox = new System.Windows.Forms.TextBox();
            this.CalculatorOutBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // Button7Digit
            // 
            this.Button7Digit.Location = new System.Drawing.Point(106, 125);
            this.Button7Digit.Name = "Button7Digit";
            this.Button7Digit.Size = new System.Drawing.Size(64, 51);
            this.Button7Digit.TabIndex = 0;
            this.Button7Digit.Text = "7";
            this.Button7Digit.UseVisualStyleBackColor = true;
            this.Button7Digit.Click += new System.EventHandler(this.Button7Digit_Click);
            // 
            // Button8Digit
            // 
            this.Button8Digit.Location = new System.Drawing.Point(176, 125);
            this.Button8Digit.Name = "Button8Digit";
            this.Button8Digit.Size = new System.Drawing.Size(64, 51);
            this.Button8Digit.TabIndex = 1;
            this.Button8Digit.Text = "8";
            this.Button8Digit.UseVisualStyleBackColor = true;
            this.Button8Digit.Click += new System.EventHandler(this.Button8Digit_Click);
            // 
            // Button9Digit
            // 
            this.Button9Digit.Location = new System.Drawing.Point(246, 125);
            this.Button9Digit.Name = "Button9Digit";
            this.Button9Digit.Size = new System.Drawing.Size(64, 51);
            this.Button9Digit.TabIndex = 2;
            this.Button9Digit.Text = "9";
            this.Button9Digit.UseVisualStyleBackColor = true;
            this.Button9Digit.Click += new System.EventHandler(this.Button9Digit_Click);
            // 
            // DivisionButton
            // 
            this.DivisionButton.Location = new System.Drawing.Point(316, 125);
            this.DivisionButton.Name = "DivisionButton";
            this.DivisionButton.Size = new System.Drawing.Size(64, 51);
            this.DivisionButton.TabIndex = 3;
            this.DivisionButton.Text = "/";
            this.DivisionButton.UseVisualStyleBackColor = true;
            this.DivisionButton.Click += new System.EventHandler(this.DivisionButton_Click);
            // 
            // SqrtButton
            // 
            this.SqrtButton.Location = new System.Drawing.Point(386, 125);
            this.SqrtButton.Name = "SqrtButton";
            this.SqrtButton.Size = new System.Drawing.Size(64, 51);
            this.SqrtButton.TabIndex = 4;
            this.SqrtButton.Text = "sqrt";
            this.SqrtButton.UseVisualStyleBackColor = true;
            this.SqrtButton.Click += new System.EventHandler(this.SqrtButton_Click);
            // 
            // Button4Digit
            // 
            this.Button4Digit.Location = new System.Drawing.Point(106, 182);
            this.Button4Digit.Name = "Button4Digit";
            this.Button4Digit.Size = new System.Drawing.Size(64, 51);
            this.Button4Digit.TabIndex = 5;
            this.Button4Digit.Text = "4";
            this.Button4Digit.UseVisualStyleBackColor = true;
            this.Button4Digit.Click += new System.EventHandler(this.Button4Digit_Click);
            // 
            // Button5Digit
            // 
            this.Button5Digit.Location = new System.Drawing.Point(176, 182);
            this.Button5Digit.Name = "Button5Digit";
            this.Button5Digit.Size = new System.Drawing.Size(64, 51);
            this.Button5Digit.TabIndex = 6;
            this.Button5Digit.Text = "5";
            this.Button5Digit.UseVisualStyleBackColor = true;
            this.Button5Digit.Click += new System.EventHandler(this.Button5Digit_Click);
            // 
            // Button6Digit
            // 
            this.Button6Digit.Location = new System.Drawing.Point(246, 182);
            this.Button6Digit.Name = "Button6Digit";
            this.Button6Digit.Size = new System.Drawing.Size(64, 51);
            this.Button6Digit.TabIndex = 7;
            this.Button6Digit.Text = "6";
            this.Button6Digit.UseVisualStyleBackColor = true;
            this.Button6Digit.Click += new System.EventHandler(this.Button6Digit_Click);
            // 
            // MultiplyButton
            // 
            this.MultiplyButton.Location = new System.Drawing.Point(316, 182);
            this.MultiplyButton.Name = "MultiplyButton";
            this.MultiplyButton.Size = new System.Drawing.Size(64, 51);
            this.MultiplyButton.TabIndex = 8;
            this.MultiplyButton.Text = "*";
            this.MultiplyButton.UseVisualStyleBackColor = true;
            this.MultiplyButton.Click += new System.EventHandler(this.MultiplyButton_Click);
            // 
            // PercentButton
            // 
            this.PercentButton.Location = new System.Drawing.Point(386, 182);
            this.PercentButton.Name = "PercentButton";
            this.PercentButton.Size = new System.Drawing.Size(64, 51);
            this.PercentButton.TabIndex = 9;
            this.PercentButton.Text = "%";
            this.PercentButton.UseVisualStyleBackColor = true;
            this.PercentButton.Click += new System.EventHandler(this.PercentButton_Click);
            // 
            // Button1Digit
            // 
            this.Button1Digit.Location = new System.Drawing.Point(106, 239);
            this.Button1Digit.Name = "Button1Digit";
            this.Button1Digit.Size = new System.Drawing.Size(64, 51);
            this.Button1Digit.TabIndex = 10;
            this.Button1Digit.Text = "1";
            this.Button1Digit.UseVisualStyleBackColor = true;
            this.Button1Digit.Click += new System.EventHandler(this.Button1Digit_Click);
            // 
            // Button2Digit
            // 
            this.Button2Digit.Location = new System.Drawing.Point(176, 239);
            this.Button2Digit.Name = "Button2Digit";
            this.Button2Digit.Size = new System.Drawing.Size(64, 51);
            this.Button2Digit.TabIndex = 11;
            this.Button2Digit.Text = "2";
            this.Button2Digit.UseVisualStyleBackColor = true;
            this.Button2Digit.Click += new System.EventHandler(this.Button2Digit_Click);
            // 
            // Button3Digit
            // 
            this.Button3Digit.Location = new System.Drawing.Point(246, 239);
            this.Button3Digit.Name = "Button3Digit";
            this.Button3Digit.Size = new System.Drawing.Size(64, 51);
            this.Button3Digit.TabIndex = 12;
            this.Button3Digit.Text = "3";
            this.Button3Digit.UseVisualStyleBackColor = true;
            this.Button3Digit.Click += new System.EventHandler(this.Button3Digit_Click);
            // 
            // SubtractionButton
            // 
            this.SubtractionButton.Location = new System.Drawing.Point(316, 239);
            this.SubtractionButton.Name = "SubtractionButton";
            this.SubtractionButton.Size = new System.Drawing.Size(64, 51);
            this.SubtractionButton.TabIndex = 13;
            this.SubtractionButton.Text = "-";
            this.SubtractionButton.UseVisualStyleBackColor = true;
            this.SubtractionButton.Click += new System.EventHandler(this.SubtractionButton_Click);
            // 
            // InverseButton
            // 
            this.InverseButton.Location = new System.Drawing.Point(386, 239);
            this.InverseButton.Name = "InverseButton";
            this.InverseButton.Size = new System.Drawing.Size(64, 51);
            this.InverseButton.TabIndex = 14;
            this.InverseButton.Text = "1/x";
            this.InverseButton.UseVisualStyleBackColor = true;
            this.InverseButton.Click += new System.EventHandler(this.InverseButton_Click);
            // 
            // Button0Digit
            // 
            this.Button0Digit.Location = new System.Drawing.Point(106, 296);
            this.Button0Digit.Name = "Button0Digit";
            this.Button0Digit.Size = new System.Drawing.Size(64, 51);
            this.Button0Digit.TabIndex = 15;
            this.Button0Digit.Text = "0";
            this.Button0Digit.UseVisualStyleBackColor = true;
            this.Button0Digit.Click += new System.EventHandler(this.Button0Digit_Click);
            // 
            // SignButton
            // 
            this.SignButton.Location = new System.Drawing.Point(176, 296);
            this.SignButton.Name = "SignButton";
            this.SignButton.Size = new System.Drawing.Size(64, 51);
            this.SignButton.TabIndex = 16;
            this.SignButton.Text = "+/-";
            this.SignButton.UseVisualStyleBackColor = true;
            this.SignButton.Click += new System.EventHandler(this.SignButton_Click);
            // 
            // DecimalButton
            // 
            this.DecimalButton.Location = new System.Drawing.Point(246, 296);
            this.DecimalButton.Name = "DecimalButton";
            this.DecimalButton.Size = new System.Drawing.Size(64, 51);
            this.DecimalButton.TabIndex = 17;
            this.DecimalButton.Text = ".";
            this.DecimalButton.UseVisualStyleBackColor = true;
            this.DecimalButton.Click += new System.EventHandler(this.DecimalButton_Click);
            // 
            // AdditionButton
            // 
            this.AdditionButton.Location = new System.Drawing.Point(316, 296);
            this.AdditionButton.Name = "AdditionButton";
            this.AdditionButton.Size = new System.Drawing.Size(64, 51);
            this.AdditionButton.TabIndex = 18;
            this.AdditionButton.Text = "+";
            this.AdditionButton.UseVisualStyleBackColor = true;
            this.AdditionButton.Click += new System.EventHandler(this.AdditionButton_Click);
            // 
            // SolveButton
            // 
            this.SolveButton.Location = new System.Drawing.Point(386, 296);
            this.SolveButton.Name = "SolveButton";
            this.SolveButton.Size = new System.Drawing.Size(64, 51);
            this.SolveButton.TabIndex = 19;
            this.SolveButton.Text = "=";
            this.SolveButton.UseVisualStyleBackColor = true;
            this.SolveButton.Click += new System.EventHandler(this.SolveButton_Click);
            // 
            // AddToMemoryButton
            // 
            this.AddToMemoryButton.Location = new System.Drawing.Point(12, 296);
            this.AddToMemoryButton.Name = "AddToMemoryButton";
            this.AddToMemoryButton.Size = new System.Drawing.Size(64, 51);
            this.AddToMemoryButton.TabIndex = 23;
            this.AddToMemoryButton.Text = "M+";
            this.AddToMemoryButton.UseVisualStyleBackColor = true;
            this.AddToMemoryButton.Click += new System.EventHandler(this.AddToMemoryButton_Click);
            // 
            // MemoryStoreButton
            // 
            this.MemoryStoreButton.Location = new System.Drawing.Point(12, 239);
            this.MemoryStoreButton.Name = "MemoryStoreButton";
            this.MemoryStoreButton.Size = new System.Drawing.Size(64, 51);
            this.MemoryStoreButton.TabIndex = 22;
            this.MemoryStoreButton.Text = "MS";
            this.MemoryStoreButton.UseVisualStyleBackColor = true;
            this.MemoryStoreButton.Click += new System.EventHandler(this.MemoryStoreButton_Click);
            // 
            // MemoryRecallButton
            // 
            this.MemoryRecallButton.Location = new System.Drawing.Point(12, 182);
            this.MemoryRecallButton.Name = "MemoryRecallButton";
            this.MemoryRecallButton.Size = new System.Drawing.Size(64, 51);
            this.MemoryRecallButton.TabIndex = 21;
            this.MemoryRecallButton.Text = "MR";
            this.MemoryRecallButton.UseVisualStyleBackColor = true;
            this.MemoryRecallButton.Click += new System.EventHandler(this.MemoryRecallButton_Click);
            // 
            // ClearMemoryButton
            // 
            this.ClearMemoryButton.Location = new System.Drawing.Point(12, 125);
            this.ClearMemoryButton.Name = "ClearMemoryButton";
            this.ClearMemoryButton.Size = new System.Drawing.Size(64, 51);
            this.ClearMemoryButton.TabIndex = 20;
            this.ClearMemoryButton.Text = "MC";
            this.ClearMemoryButton.UseVisualStyleBackColor = true;
            this.ClearMemoryButton.Click += new System.EventHandler(this.ClearMemoryButton_Click);
            // 
            // BackspaceButton
            // 
            this.BackspaceButton.Location = new System.Drawing.Point(106, 66);
            this.BackspaceButton.Name = "BackspaceButton";
            this.BackspaceButton.Size = new System.Drawing.Size(116, 41);
            this.BackspaceButton.TabIndex = 24;
            this.BackspaceButton.Text = "Backspace";
            this.BackspaceButton.UseVisualStyleBackColor = true;
            this.BackspaceButton.Click += new System.EventHandler(this.BackspaceButton_Click);
            // 
            // ClearEntryButton
            // 
            this.ClearEntryButton.Location = new System.Drawing.Point(228, 66);
            this.ClearEntryButton.Name = "ClearEntryButton";
            this.ClearEntryButton.Size = new System.Drawing.Size(100, 41);
            this.ClearEntryButton.TabIndex = 25;
            this.ClearEntryButton.Text = "CE";
            this.ClearEntryButton.UseVisualStyleBackColor = true;
            this.ClearEntryButton.Click += new System.EventHandler(this.ClearEntryButton_Click);
            // 
            // ClearButton
            // 
            this.ClearButton.Location = new System.Drawing.Point(334, 66);
            this.ClearButton.Name = "ClearButton";
            this.ClearButton.Size = new System.Drawing.Size(116, 41);
            this.ClearButton.TabIndex = 26;
            this.ClearButton.Text = "C";
            this.ClearButton.UseVisualStyleBackColor = true;
            this.ClearButton.Click += new System.EventHandler(this.ClearButton_Click);
            // 
            // MemoryExistsBox
            // 
            this.MemoryExistsBox.Location = new System.Drawing.Point(12, 77);
            this.MemoryExistsBox.Name = "MemoryExistsBox";
            this.MemoryExistsBox.ReadOnly = true;
            this.MemoryExistsBox.Size = new System.Drawing.Size(64, 20);
            this.MemoryExistsBox.TabIndex = 27;
            this.MemoryExistsBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // CalculatorOutBox
            // 
            this.CalculatorOutBox.BackColor = System.Drawing.SystemColors.Window;
            this.CalculatorOutBox.Location = new System.Drawing.Point(12, 25);
            this.CalculatorOutBox.Name = "CalculatorOutBox";
            this.CalculatorOutBox.ReadOnly = true;
            this.CalculatorOutBox.Size = new System.Drawing.Size(437, 20);
            this.CalculatorOutBox.TabIndex = 28;
            this.CalculatorOutBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Calculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(467, 361);
            this.Controls.Add(this.CalculatorOutBox);
            this.Controls.Add(this.MemoryExistsBox);
            this.Controls.Add(this.ClearButton);
            this.Controls.Add(this.ClearEntryButton);
            this.Controls.Add(this.BackspaceButton);
            this.Controls.Add(this.AddToMemoryButton);
            this.Controls.Add(this.MemoryStoreButton);
            this.Controls.Add(this.MemoryRecallButton);
            this.Controls.Add(this.ClearMemoryButton);
            this.Controls.Add(this.SolveButton);
            this.Controls.Add(this.AdditionButton);
            this.Controls.Add(this.DecimalButton);
            this.Controls.Add(this.SignButton);
            this.Controls.Add(this.Button0Digit);
            this.Controls.Add(this.InverseButton);
            this.Controls.Add(this.SubtractionButton);
            this.Controls.Add(this.Button3Digit);
            this.Controls.Add(this.Button2Digit);
            this.Controls.Add(this.Button1Digit);
            this.Controls.Add(this.PercentButton);
            this.Controls.Add(this.MultiplyButton);
            this.Controls.Add(this.Button6Digit);
            this.Controls.Add(this.Button5Digit);
            this.Controls.Add(this.Button4Digit);
            this.Controls.Add(this.SqrtButton);
            this.Controls.Add(this.DivisionButton);
            this.Controls.Add(this.Button9Digit);
            this.Controls.Add(this.Button8Digit);
            this.Controls.Add(this.Button7Digit);
            this.Name = "Calculator";
            this.Text = "Windows Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Button7Digit;
        private System.Windows.Forms.Button Button8Digit;
        private System.Windows.Forms.Button Button9Digit;
        private System.Windows.Forms.Button DivisionButton;
        private System.Windows.Forms.Button SqrtButton;
        private System.Windows.Forms.Button Button4Digit;
        private System.Windows.Forms.Button Button5Digit;
        private System.Windows.Forms.Button Button6Digit;
        private System.Windows.Forms.Button MultiplyButton;
        private System.Windows.Forms.Button PercentButton;
        private System.Windows.Forms.Button Button1Digit;
        private System.Windows.Forms.Button Button2Digit;
        private System.Windows.Forms.Button Button3Digit;
        private System.Windows.Forms.Button SubtractionButton;
        private System.Windows.Forms.Button InverseButton;
        private System.Windows.Forms.Button Button0Digit;
        private System.Windows.Forms.Button SignButton;
        private System.Windows.Forms.Button DecimalButton;
        private System.Windows.Forms.Button AdditionButton;
        private System.Windows.Forms.Button SolveButton;
        private System.Windows.Forms.Button AddToMemoryButton;
        private System.Windows.Forms.Button MemoryStoreButton;
        private System.Windows.Forms.Button MemoryRecallButton;
        private System.Windows.Forms.Button ClearMemoryButton;
        private System.Windows.Forms.Button BackspaceButton;
        private System.Windows.Forms.Button ClearEntryButton;
        private System.Windows.Forms.Button ClearButton;
        private System.Windows.Forms.TextBox MemoryExistsBox;
        private System.Windows.Forms.TextBox CalculatorOutBox;
    }
}

